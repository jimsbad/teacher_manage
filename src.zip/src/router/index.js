import { createRouter, createWebHistory } from 'vue-router'
import Layout from '../Layout/Layout.vue'

const routes = [
  {
    path: '/',
    name: 'Layout',
    component: Layout,
    redirect: "/course",
    children: [
      {
        path: 'ggg',
        name: 'ggg',
        component: () => import("@/views/ggg"),
      },
      {
        path: 'hhh',
        name: 'hhh',
        component: () => import("@/views/hhh"),
      },
      {
        path: 'compete',
        name: 'compete',
        component: () => import("@/views/compete"),
      },
      {
        path: 'course',
        name: 'course',
        component: () => import("@/views/course"),
      },
      {
        path: 'bbb',
        name: 'bbb',
        component: () => import("@/views/bbb"),
      },
      {
        path: 'ccc',
        name: 'ccc',
        component: () => import("@/views/ccc"),
      },
      {
        path: 'ddd',
        name: 'ddd',
        component: () => import("@/views/ddd"),
      },
      {
        path: 'eee',
        name: 'eee',
        component: () => import("@/views/eee"),
      }, 
      {
        path: 'fff',
        name: 'fff',
        component: () => import("@/views/fff"),
      },
    ]
  },
]

const router = createRouter({
  history: createWebHistory(process.env.BASE_URL),
  routes
})

export default router
